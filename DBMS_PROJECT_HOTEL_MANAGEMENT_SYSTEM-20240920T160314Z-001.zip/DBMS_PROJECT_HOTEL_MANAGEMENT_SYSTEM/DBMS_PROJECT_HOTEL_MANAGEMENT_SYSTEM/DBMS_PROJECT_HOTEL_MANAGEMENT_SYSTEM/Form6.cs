﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS_PROJECT_HOTEL_MANAGEMENT_SYSTEM
{
    public partial class ROOMS_FORM : Form
    {
        public ROOMS_FORM()
        {
           InitializeComponent();
        }

        private void ROOMS_FORM_Load(object sender, EventArgs e)
        {

        }

        private void ROOMS_FORM_Load_1(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            this.Hide();
            obj.Show();
        }

        private void panel12_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            BOOKING_PAGE obj1 = new BOOKING_PAGE();
            this.Hide();
            obj1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BOOKING_PAGE obj1 = new BOOKING_PAGE();
            this.Hide();
            obj1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BOOKING_PAGE obj1 = new BOOKING_PAGE();
            this.Hide();
            obj1.Show();
        }
    }
}
